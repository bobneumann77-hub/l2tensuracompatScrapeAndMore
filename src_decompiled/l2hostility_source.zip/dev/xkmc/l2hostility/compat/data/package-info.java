@MethodsReturnNonnullByDefault
@ParametersAreNonnullByDefault
package dev.xkmc.l2hostility.compat.data;

import javax.annotation.ParametersAreNonnullByDefault;
import net.minecraft.MethodsReturnNonnullByDefault;
