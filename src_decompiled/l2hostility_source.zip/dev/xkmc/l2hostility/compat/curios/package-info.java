@MethodsReturnNonnullByDefault
@ParametersAreNonnullByDefault
package dev.xkmc.l2hostility.compat.curios;

import javax.annotation.ParametersAreNonnullByDefault;
import net.minecraft.MethodsReturnNonnullByDefault;
