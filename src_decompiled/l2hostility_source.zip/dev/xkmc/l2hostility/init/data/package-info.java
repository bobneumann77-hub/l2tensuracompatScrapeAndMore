@MethodsReturnNonnullByDefault
@ParametersAreNonnullByDefault
package dev.xkmc.l2hostility.init.data;

import javax.annotation.ParametersAreNonnullByDefault;
import net.minecraft.MethodsReturnNonnullByDefault;
