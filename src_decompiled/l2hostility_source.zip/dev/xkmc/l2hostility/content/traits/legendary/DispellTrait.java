package dev.xkmc.l2hostility.content.traits.legendary;

import dev.xkmc.l2damagetracker.contents.attack.CreateSourceEvent;
import dev.xkmc.l2damagetracker.contents.attack.DamageModifier;
import dev.xkmc.l2damagetracker.contents.attack.DamageData.Defence;
import dev.xkmc.l2damagetracker.contents.damage.DefaultDamageState;
import dev.xkmc.l2damagetracker.init.data.L2DamageTypes;
import dev.xkmc.l2hostility.content.item.traits.EnchantmentDisabler;
import dev.xkmc.l2hostility.init.data.LHConfig;
import dev.xkmc.l2hostility.init.registrate.LHItems;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.core.RegistryAccess;
import net.minecraft.network.chat.Component;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.common.Tags.DamageTypes;

public class DispellTrait extends LegendaryTrait {
   public DispellTrait(ChatFormatting style) {
      super(style);
   }

   @Override
   public void onCreateSource(int level, LivingEntity attacker, CreateSourceEvent event) {
      if (event.getResult() == L2DamageTypes.MOB_ATTACK) {
         event.enable(DefaultDamageState.BYPASS_MAGIC);
      }
   }

   @Override
   public void postHurtImpl(int level, LivingEntity attacker, LivingEntity target) {
      List<ItemStack> list = new ArrayList<>();

      for (EquipmentSlot slot : EquipmentSlot.values()) {
         ItemStack stack = target.getItemBySlot(slot);
         if (stack.isEnchanted() && LHItems.DC_DISPELL_ENCH.get(stack) == null) {
            list.add(stack);
         }
      }

      if (!list.isEmpty()) {
         int time = (Integer)LHConfig.SERVER.dispellTime.get() * level;
         int count = Math.min(level, list.size());

         for (int i = 0; i < count; i++) {
            int index = attacker.getRandom().nextInt(list.size());
            EnchantmentDisabler.disableEnchantment(attacker.level(), list.remove(index), time);
         }
      }
   }

   @Override
   public void onDamaged(int level, LivingEntity entity, Defence event) {
      if (!event.getSource().is(DamageTypeTags.BYPASSES_INVULNERABILITY)
         && !event.getSource().is(DamageTypeTags.BYPASSES_EFFECTS)
         && event.getSource().is(DamageTypes.IS_MAGIC)) {
         double def = (Double)LHConfig.SERVER.dispellDamageReductionBase.get();
         event.addDealtModifier(
            DamageModifier.nonlinearPre(7435, val -> (float)(val < def ? val / def : Math.log(val) / Math.log(def)), this.getRegistryName())
         );
      }
   }

   @Override
   public void addDetail(RegistryAccess access, List<Component> list) {
      list.add(
         Component.translatable(
               this.getDescriptionId() + ".desc",
               new Object[]{
                  this.mapLevel(access, i -> Component.literal(i + "").withStyle(ChatFormatting.AQUA)),
                  this.mapLevel(access, i -> Component.literal((Integer)LHConfig.SERVER.dispellTime.get() * i / 20 + "").withStyle(ChatFormatting.AQUA))
               }
            )
            .withStyle(ChatFormatting.GRAY)
      );
   }
}
