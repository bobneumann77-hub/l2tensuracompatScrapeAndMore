package dev.xkmc.l2hostility.content.capability.mob;

import dev.xkmc.l2core.capability.attachment.GeneralCapabilityHolder;
import dev.xkmc.l2hostility.init.registrate.LHMiscs;
import dev.xkmc.l2serial.serialization.codec.TagCodec;
import dev.xkmc.l2serial.serialization.marker.SerialField;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;

public class ClientCapHandler {
   public static void handle(MobCapSyncToClient packet) {
      Level level = Minecraft.getInstance().level;
      if (level != null) {
         if (level.getEntity(packet.id()) instanceof LivingEntity le) {
            MobTraitCap opt = (MobTraitCap)((GeneralCapabilityHolder)LHMiscs.MOB.type()).getOrCreate(le);
            new TagCodec(level.registryAccess()).pred(SerialField::toClient).fromTag(packet.tag(), MobTraitCap.class, opt);
         }
      }
   }
}
