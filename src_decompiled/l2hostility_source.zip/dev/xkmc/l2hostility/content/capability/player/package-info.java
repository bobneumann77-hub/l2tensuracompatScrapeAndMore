@MethodsReturnNonnullByDefault
@ParametersAreNonnullByDefault
package dev.xkmc.l2hostility.content.capability.player;

import javax.annotation.ParametersAreNonnullByDefault;
import net.minecraft.MethodsReturnNonnullByDefault;
