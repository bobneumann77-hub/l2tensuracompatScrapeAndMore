@MethodsReturnNonnullByDefault
@ParametersAreNonnullByDefault
package dev.xkmc.l2hostility.content.item.beacon;

import javax.annotation.ParametersAreNonnullByDefault;
import net.minecraft.MethodsReturnNonnullByDefault;
